cd /home/ammad/Downloads/traccar-web-master/tools/
./minify.sh
