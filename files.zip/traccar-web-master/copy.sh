sudo cp -r /home/ammad/Downloads/traccar-web-master/web/ /opt/traccar/
